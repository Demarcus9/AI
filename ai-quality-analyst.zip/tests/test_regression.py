from ai_quality.models import EvaluationReport
from ai_quality.regression import compare_reports

def test_regression():
    base = EvaluationReport(total_cases=1, passed_cases=1, failed_cases=0,
                            average_score=.95, cases=[])
    current = EvaluationReport(total_cases=1, passed_cases=1, failed_cases=0,
                               average_score=.85, cases=[])
    assert compare_reports(base, current)["regression_detected"]
