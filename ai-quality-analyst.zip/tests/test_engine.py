from ai_quality.engine import QualityEngine
from ai_quality.metrics import default_metrics
from ai_quality.models import QualityCase

def test_engine():
    cases = [QualityCase(id="1", prompt="Explain testing",
                         response="Testing finds defects and reduces risk.",
                         metadata={"required_terms":["testing","defects"]})]
    report = QualityEngine(default_metrics()).evaluate(cases)
    assert report.total_cases == 1
    assert 0 <= report.average_score <= 1
