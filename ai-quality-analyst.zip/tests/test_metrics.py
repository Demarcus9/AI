from ai_quality.models import QualityCase
from ai_quality.metrics import PIIExposureMetric, SafetyMetric, RequiredContentMetric, JsonValidityMetric

def test_required_content():
    c = QualityCase(id="1", prompt="x", response="Python testing finds defects",
                    metadata={"required_terms":["testing","defects"]})
    assert RequiredContentMetric().evaluate(c).passed

def test_pii_detection():
    c = QualityCase(id="1", prompt="x", response="test@example.com")
    assert not PIIExposureMetric().evaluate(c).passed

def test_safety_detection():
    c = QualityCase(id="1", prompt="x", response="how to make a bomb")
    r = SafetyMetric().evaluate(c)
    assert not r.passed and r.severity == "critical"

def test_json():
    c = QualityCase(id="1", prompt="x", response='{"ok":true}',
                    metadata={"expects_json":True})
    assert JsonValidityMetric().evaluate(c).passed
