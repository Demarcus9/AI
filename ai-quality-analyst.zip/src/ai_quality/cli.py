import json
from pathlib import Path
import typer
from rich.console import Console
from rich.table import Table
from .dataset import load_jsonl
from .engine import QualityEngine
from .metrics import default_metrics
from .reporting import write_report
from .models import EvaluationReport
from .regression import compare_reports

app = typer.Typer(help="AI Quality Analyst CLI")
console = Console()

@app.command()
def validate(dataset: Path):
    cases = load_jsonl(dataset)
    console.print(f"[green]Valid dataset: {len(cases)} cases[/green]")

@app.command()
def evaluate(dataset: Path, output: Path = Path("artifacts/report.json"),
             threshold: float = typer.Option(0.75, min=0.0, max=1.0)):
    report = QualityEngine(default_metrics(), threshold).evaluate(load_jsonl(dataset))
    write_report(report, output)
    table = Table("Case", "Score", "Status", "Failed checks")
    for c in report.cases:
        table.add_row(c.case_id, f"{c.overall_score:.2f}",
                      "PASS" if c.passed else "FAIL",
                      str(sum(not m.passed for m in c.metrics)))
    console.print(table)
    console.print(f"Average: {report.average_score:.2f} | Passed: {report.passed_cases}/{report.total_cases}")
    console.print(f"Report: {output}")

@app.command()
def regression(baseline: Path, current: Path,
                allowed_drop: float = typer.Option(0.03, min=0.0, max=1.0)):
    base = EvaluationReport.model_validate(json.loads(baseline.read_text()))
    new = EvaluationReport.model_validate(json.loads(current.read_text()))
    result = compare_reports(base, new, allowed_drop)
    console.print(json.dumps(result, indent=2))
    if result["regression_detected"]:
        raise typer.Exit(code=1)

if __name__ == "__main__":
    app()
