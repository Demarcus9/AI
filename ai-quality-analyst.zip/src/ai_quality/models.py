from __future__ import annotations
from datetime import datetime, timezone
from typing import Any
from pydantic import BaseModel, Field

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class QualityCase(BaseModel):
    id: str
    prompt: str
    response: str
    expected: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

class MetricResult(BaseModel):
    name: str
    score: float
    passed: bool
    severity: str = "info"
    findings: list[str] = Field(default_factory=list)
    details: dict[str, Any] = Field(default_factory=dict)

class CaseReport(BaseModel):
    case_id: str
    overall_score: float
    passed: bool
    metrics: list[MetricResult]
    created_at: datetime = Field(default_factory=utc_now)

class EvaluationReport(BaseModel):
    total_cases: int
    passed_cases: int
    failed_cases: int
    average_score: float
    cases: list[CaseReport]
    created_at: datetime = Field(default_factory=utc_now)
