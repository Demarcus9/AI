from .models import MetricResult

WEIGHTS = {
    "required_content": 0.20,
    "relevance": 0.20,
    "pii_exposure": 0.20,
    "safety": 0.20,
    "length": 0.10,
    "json_validity": 0.10,
}

def weighted_score(metrics: list[MetricResult], threshold: float = 0.75):
    denominator = sum(WEIGHTS.get(m.name, 0) for m in metrics)
    score = (sum(m.score * WEIGHTS.get(m.name, 0) for m in metrics) / denominator
             if denominator else 0.0)
    critical = any(m.severity == "critical" and not m.passed for m in metrics)
    return round(score, 4), score >= threshold and not critical
