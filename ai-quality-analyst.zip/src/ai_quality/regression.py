def compare_reports(baseline, current, allowed_drop=0.03):
    delta = round(current.average_score - baseline.average_score, 4)
    return {
        "baseline_score": baseline.average_score,
        "current_score": current.average_score,
        "delta": delta,
        "allowed_drop": allowed_drop,
        "regression_detected": delta < -allowed_drop,
    }
