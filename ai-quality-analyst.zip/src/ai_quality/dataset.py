import json
from pathlib import Path
from .models import QualityCase

def load_jsonl(path: str | Path):
    cases = []
    with Path(path).open(encoding="utf-8") as fh:
        for line_no, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                cases.append(QualityCase.model_validate(json.loads(line)))
            except Exception as exc:
                raise ValueError(f"Invalid record at line {line_no}: {exc}") from exc
    if not cases:
        raise ValueError("Dataset contains no cases")
    return cases
