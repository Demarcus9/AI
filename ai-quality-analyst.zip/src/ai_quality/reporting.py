import json
from pathlib import Path

def write_report(report, path):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(report.model_dump(mode="json"), indent=2),
                 encoding="utf-8")
