from .models import QualityCase, CaseReport, EvaluationReport
from .scoring import weighted_score

class QualityEngine:
    def __init__(self, metrics, threshold=0.75):
        self.metrics = list(metrics)
        self.threshold = threshold

    def evaluate_case(self, case: QualityCase):
        metrics = [m.evaluate(case) for m in self.metrics]
        score, passed = weighted_score(metrics, self.threshold)
        return CaseReport(case_id=case.id, overall_score=score,
                          passed=passed, metrics=metrics)

    def evaluate(self, cases):
        reports = [self.evaluate_case(c) for c in cases]
        passed = sum(r.passed for r in reports)
        average = sum(r.overall_score for r in reports) / len(reports)
        return EvaluationReport(total_cases=len(reports), passed_cases=passed,
            failed_cases=len(reports)-passed, average_score=round(average,4),
            cases=reports)
