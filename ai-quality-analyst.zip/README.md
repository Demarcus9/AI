# AI Quality Analyst

A production-oriented Python platform for automated quality assurance of AI/LLM responses.

## Capabilities
- Relevance and required-content checks
- Hallucination/groundedness signals via configurable expected content
- Safety pattern detection
- PII exposure detection
- Response-length checks
- JSON validity checks
- Weighted quality scoring
- Regression comparison between evaluation runs
- JSONL datasets and JSON reports
- CLI automation
- Pytest test suite
- GitHub Actions CI

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -e ".[dev]"
pytest
python -m ai_quality validate data/sample_cases.jsonl
python -m ai_quality evaluate data/sample_cases.jsonl --output artifacts/report.json
```

## Architecture

```text
Evaluation Dataset
       |
       v
Quality Engine
 |       |       |
Safety  Privacy  Relevance
 |       |       |
 +-------+-------+
         |
   Weighted Scoring
         |
   JSON Report / CLI
```

## Senior engineering design

The project separates domain models, metrics, scoring, orchestration, datasets, reporting, and CLI concerns. Metrics are pluggable, results are structured, and regression checks can be used in CI to prevent model-quality degradation.

## Production roadmap

Add real LLM-as-a-judge adapters, PostgreSQL, FastAPI, Redis/Celery workers, OpenTelemetry, Prometheus, human-review queues, dataset versioning, model/provider adapters, and experiment tracking.
